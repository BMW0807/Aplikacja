/* ══════════════════════════════════════════════
   Serwerek Chat — Frontend JavaScript
   Auth | Chat | WebSocket | WebRTC Voice
══════════════════════════════════════════════ */

const API = window.location.origin;
let token       = localStorage.getItem('srw_token') || null;
let currentUser = null;
let socket      = null;
let currentServer  = null;
let currentChannel = null;
let servers = [];

// reCAPTCHA widget IDs
let rcLogin = null, rcRegister = null;

// Voice state
let localStream   = null;
let peerConn      = null;
let inVoice       = false;
let micMuted      = false;
let deafened      = false;
const remoteStreams = {};

// Typing state
let typingTimer = null;

// ── Utilities ────────────────────────────────────
const $ = id => document.getElementById(id);
const show = el => el.classList.remove('hidden');
const hide = el => el.classList.add('hidden');

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px)';
    el.style.transition = '.3s ease';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

function formatTime(iso) {
  const d = new Date(iso + 'Z');
  return d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(iso) {
  const d = new Date(iso + 'Z');
  const today = new Date();
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Dzisiaj';
  if (d.toDateString() === yesterday.toDateString()) return 'Wczoraj';
  return d.toLocaleDateString('pl-PL', { day: 'numeric', month: 'long', year: 'numeric' });
}

async function api(path, options = {}) {
  const opts = {
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...options,
  };
  const res = await fetch(API + path, opts);
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || 'Błąd serwera');
  return json;
}

// ── reCAPTCHA init ────────────────────────────────
async function initRecaptcha() {
  try {
    const { key } = await api('/api/recaptcha-site-key');
    if (typeof grecaptcha === 'undefined') {
      await new Promise(r => {
        const check = setInterval(() => {
          if (typeof grecaptcha !== 'undefined') { clearInterval(check); r(); }
        }, 200);
      });
    }
    grecaptcha.ready(() => {
      if (!rcLogin) {
        rcLogin = grecaptcha.render('recaptcha-login', { sitekey: key, theme: 'dark' });
      }
      if (!rcRegister) {
        rcRegister = grecaptcha.render('recaptcha-register', { sitekey: key, theme: 'dark' });
      }
    });
  } catch (e) {
    console.warn('reCAPTCHA init failed:', e);
  }
}

function getRecaptchaToken(widgetId) {
  try {
    return grecaptcha.getResponse(widgetId) || '';
  } catch { return ''; }
}

function resetRecaptcha(widgetId) {
  try { grecaptcha.reset(widgetId); } catch {}
}

// ── Auth ──────────────────────────────────────────
document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
    tab.classList.add('active');
    $(`form-${tab.dataset.tab}`).classList.add('active');
  });
});

$('btn-login').addEventListener('click', async () => {
  const username = $('login-username').value.trim();
  const password = $('login-password').value;
  const captcha  = getRecaptchaToken(rcLogin);
  $('login-error').textContent = '';
  try {
    const data = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, captcha }),
    });
    token = data.token;
    localStorage.setItem('srw_token', token);
    currentUser = data.user;
    enterApp();
  } catch (e) {
    $('login-error').textContent = e.message;
    resetRecaptcha(rcLogin);
  }
});

$('btn-register').addEventListener('click', async () => {
  const username  = $('reg-username').value.trim();
  const password  = $('reg-password').value;
  const password2 = $('reg-password2').value;
  const captcha   = getRecaptchaToken(rcRegister);
  $('register-error').textContent = '';

  if (password !== password2) {
    $('register-error').textContent = 'Hasła nie są identyczne';
    return;
  }
  try {
    await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, password, captcha }),
    });
    toast('Konto utworzone! Zaloguj się.');
    // Switch to login tab
    document.querySelector('[data-tab="login"]').click();
    resetRecaptcha(rcRegister);
  } catch (e) {
    $('register-error').textContent = e.message;
    resetRecaptcha(rcRegister);
  }
});

// Enter on inputs
[$('login-password'), $('login-username')].forEach(el => {
  el.addEventListener('keydown', e => { if (e.key === 'Enter') $('btn-login').click(); });
});

// ── App Init ──────────────────────────────────────
async function enterApp() {
  hide($('auth-screen'));
  show($('app-screen'));
  $('panel-username').textContent = currentUser.username;
  $('panel-avatar').textContent   = currentUser.username[0].toUpperCase();
  connectSocket();
  await loadServers();
}

async function loadServers() {
  try {
    servers = await api('/api/servers');
    renderServerList();
    if (servers.length > 0) selectServer(servers[0]);
  } catch (e) { console.error(e); }
}

function renderServerList() {
  // Remove existing server icons (keep static buttons)
  document.querySelectorAll('.server-icon.dynamic').forEach(el => el.remove());
  const nav = $('server-list');
  servers.forEach(s => {
    const icon = document.createElement('div');
    icon.className = 'server-icon dynamic';
    icon.dataset.id = s.id;
    icon.title = s.name;
    icon.textContent = s.name[0].toUpperCase();
    icon.addEventListener('click', () => selectServer(s));
    nav.appendChild(icon);
  });
}

async function selectServer(server) {
  currentServer = server;
  document.querySelectorAll('.server-icon.dynamic').forEach(el => {
    el.classList.toggle('active', el.dataset.id === server.id);
  });
  try {
    const full = await api(`/api/servers/${server.id}`);
    currentServer = full;
    $('server-name').textContent = full.name;
    renderChannels(full.channels);
    renderMembers(full.members);
    // Auto-select first text channel
    const first = full.channels.find(c => c.type === 'text');
    if (first) selectChannel(first);
  } catch (e) { console.error(e); }
}

function renderChannels(channels) {
  const list = $('channel-list');
  list.innerHTML = '';

  const textChs  = channels.filter(c => c.type === 'text');
  const voiceChs = channels.filter(c => c.type === 'voice');

  if (textChs.length) {
    list.insertAdjacentHTML('beforeend', '<div class="channel-group-label">Tekstowe</div>');
    textChs.forEach(ch => list.appendChild(channelItem(ch)));
  }
  if (voiceChs.length) {
    list.insertAdjacentHTML('beforeend', '<div class="channel-group-label">Głosowe</div>');
    voiceChs.forEach(ch => list.appendChild(channelItem(ch)));
  }
}

function channelItem(ch) {
  const el = document.createElement('div');
  el.className = 'channel-item';
  el.dataset.id = ch.id;
  el.innerHTML = `
    <span class="channel-prefix">${ch.type === 'voice' ? '🔊' : '#'}</span>
    <span>${ch.name}</span>
  `;
  el.addEventListener('click', () => selectChannel(ch));
  return el;
}

function selectChannel(ch) {
  currentChannel = ch;
  document.querySelectorAll('.channel-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === ch.id);
  });
  $('header-channel-name').textContent = ch.name;
  $('header-channel-type').textContent = ch.type === 'voice' ? '🔊' : '#';

  if (ch.type === 'voice') {
    hide($('message-bar'));
    hide($('welcome-msg'));
    show($('voice-bar'));
    $('voice-channel-name').textContent = ch.name;
    joinVoice(ch.id);
  } else {
    show($('message-bar'));
    hide($('voice-bar'));
    if (inVoice) leaveVoice();
    loadMessages(ch.id);
    if (socket) socket.emit('join_channel', { channel_id: ch.id });
    $('message-input').focus();
  }
}

// ── Messages ──────────────────────────────────────
let lastAuthor = null, lastDate = null;

async function loadMessages(channelId) {
  const container = $('messages');
  container.innerHTML = '';
  lastAuthor = null; lastDate = null;
  try {
    const msgs = await api(`/api/channels/${channelId}/messages?limit=50`);
    msgs.forEach(m => appendMessage(m, false));
    container.scrollTop = container.scrollHeight;
  } catch (e) { console.error(e); }
}

function appendMessage(msg, scroll = true) {
  const container = $('messages');
  const msgDate = formatDate(msg.created);

  // Date divider
  if (msgDate !== lastDate) {
    lastDate = msgDate;
    const div = document.createElement('div');
    div.className = 'date-divider';
    div.textContent = msgDate;
    container.appendChild(div);
    lastAuthor = null;
  }

  if (msg.user_id === lastAuthor) {
    // Continuation
    const el = document.createElement('div');
    el.className = 'msg-cont';
    el.innerHTML = `<div class="msg-content">${escapeHtml(msg.content)}</div>`;
    container.appendChild(el);
  } else {
    lastAuthor = msg.user_id;
    const el = document.createElement('div');
    el.className = 'msg-group';
    el.innerHTML = `
      <div class="msg-avatar">${(msg.username || '?')[0].toUpperCase()}</div>
      <div class="msg-body">
        <div class="msg-meta">
          <span class="msg-author">${escapeHtml(msg.username)}</span>
          <span class="msg-time">${formatTime(msg.created)}</span>
        </div>
        <div class="msg-content">${escapeHtml(msg.content)}</div>
      </div>
    `;
    container.appendChild(el);
  }

  if (scroll) {
    const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 100;
    if (isAtBottom) container.scrollTop = container.scrollHeight;
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;')
    .replace(/\n/g,'<br>');
}

// Send message
async function sendMessage() {
  const input = $('message-input');
  const content = input.textContent.trim();
  if (!content || !currentChannel) return;
  input.textContent = '';
  try {
    await api(`/api/channels/${currentChannel.id}/messages`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  } catch (e) { toast(e.message, 'error'); }
}

$('btn-send').addEventListener('click', sendMessage);
$('message-input').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
  // Typing indicator
  if (socket && currentChannel) {
    socket.emit('typing', { channel_id: currentChannel.id });
  }
});

// ── Members ───────────────────────────────────────
function renderMembers(members) {
  const list = $('members-list');
  list.innerHTML = '';
  const online  = members.filter(m => m.status === 'online');
  const offline = members.filter(m => m.status !== 'online');

  if (online.length) {
    list.insertAdjacentHTML('beforeend', `<div class="channel-group-label">Online — ${online.length}</div>`);
    online.forEach(m => list.appendChild(memberItem(m, true)));
  }
  if (offline.length) {
    list.insertAdjacentHTML('beforeend', `<div class="channel-group-label">Offline — ${offline.length}</div>`);
    offline.forEach(m => list.appendChild(memberItem(m, false)));
  }
}

function memberItem(m, online) {
  const el = document.createElement('div');
  el.className = `member-item ${online ? 'online' : ''}`;
  el.innerHTML = `
    <div class="member-avatar" style="position:relative">
      ${m.username[0].toUpperCase()}
      <span class="status-dot ${online ? 'online' : 'offline'}" style="position:absolute;bottom:-1px;right:-1px"></span>
    </div>
    <span class="member-name">${escapeHtml(m.username)}</span>
  `;
  return el;
}

// ── Members panel toggle ──────────────────────────
let membersOpen = false;
$('btn-members-toggle').addEventListener('click', () => {
  membersOpen = !membersOpen;
  const app = $('app-screen');
  const panel = $('members-panel');
  if (membersOpen) { show(panel); app.classList.add('with-members'); }
  else { hide(panel); app.classList.remove('with-members'); }
});

// ── WebSocket ─────────────────────────────────────
function connectSocket() {
  socket = io(API, { auth: { token }, query: { token }, transports: ['websocket', 'polling'] });

  socket.on('connect', () => console.log('Socket connected'));
  socket.on('disconnect', () => console.log('Socket disconnected'));

  socket.on('new_message', msg => {
    if (currentChannel && msg.channel_id === currentChannel.id) {
      appendMessage(msg);
    }
  });

  socket.on('user_typing', ({ username, channel_id }) => {
    if (currentChannel && channel_id === currentChannel.id) {
      showTyping(username);
    }
  });

  // Voice signaling
  socket.on('voice_participants', async ({ participants }) => {
    for (const p of participants) {
      await initiateVoiceCall(p.id);
    }
  });
  socket.on('voice_joined', ({ user }) => {
    addVoiceUser(user);
    initiateVoiceCall(user.id);
  });
  socket.on('voice_left', ({ user_id }) => removeVoiceUser(user_id));
  socket.on('webrtc_offer',  handleOffer);
  socket.on('webrtc_answer', handleAnswer);
  socket.on('webrtc_ice',    handleIce);
}

// Typing indicator
let typingUsers = {};
let typingClear = {};
function showTyping(username) {
  typingUsers[username] = true;
  clearTimeout(typingClear[username]);
  typingClear[username] = setTimeout(() => {
    delete typingUsers[username];
    updateTypingIndicator();
  }, 3000);
  updateTypingIndicator();
}
function updateTypingIndicator() {
  const names = Object.keys(typingUsers);
  const el = $('typing-indicator');
  if (!names.length) { el.innerHTML = ''; return; }
  const text = names.length === 1 ? `${names[0]} pisze...` : `${names.join(', ')} piszą...`;
  el.innerHTML = `<span class="typing-dots"><span></span><span></span><span></span></span> ${escapeHtml(text)}`;
}

// ── Voice (WebRTC) ────────────────────────────────
async function joinVoice(channelId) {
  if (inVoice) await leaveVoice();
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    inVoice = true;
    show($('voice-bar'));
    if (socket) socket.emit('voice_join', { channel_id: channelId });
    toast('Dołączono do kanału głosowego 🎤');
  } catch (e) {
    toast('Brak dostępu do mikrofonu', 'error');
    console.error(e);
  }
}

async function leaveVoice() {
  if (!inVoice) return;
  inVoice = false;
  if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
  if (peerConn) { peerConn.close(); peerConn = null; }
  Object.values(remoteStreams).forEach(a => a.remove());
  Object.keys(remoteStreams).forEach(k => delete remoteStreams[k]);
  if (socket && currentChannel) socket.emit('voice_leave', { channel_id: currentChannel.id });
  hide($('voice-bar'));
}

function createPeer() {
  const pc = new RTCPeerConnection({
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ]
  });
  if (localStream) localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.onicecandidate = ({ candidate }) => {
    if (candidate && socket && currentChannel) {
      socket.emit('webrtc_ice', { candidate, channel_id: currentChannel.id });
    }
  };
  pc.ontrack = ({ streams }) => {
    const stream = streams[0];
    let audio = document.createElement('audio');
    audio.srcObject = stream;
    audio.autoplay = true;
    if (deafened) audio.muted = true;
    $('audio-container').appendChild(audio);
    remoteStreams[stream.id] = audio;
  };
  return pc;
}

async function initiateVoiceCall(targetUserId) {
  if (!localStream || !currentChannel) return;
  peerConn = createPeer();
  const offer = await peerConn.createOffer();
  await peerConn.setLocalDescription(offer);
  socket.emit('webrtc_offer', { offer, channel_id: currentChannel.id, target: targetUserId });
}

async function handleOffer({ offer, channel_id }) {
  if (!localStream) return;
  if (!currentChannel || currentChannel.id !== channel_id) return;
  peerConn = createPeer();
  await peerConn.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await peerConn.createAnswer();
  await peerConn.setLocalDescription(answer);
  socket.emit('webrtc_answer', { answer, channel_id });
}

async function handleAnswer({ answer }) {
  if (peerConn) await peerConn.setRemoteDescription(new RTCSessionDescription(answer));
}

async function handleIce({ candidate }) {
  if (peerConn && candidate) {
    await peerConn.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
  }
}

// Voice user list in sidebar
function addVoiceUser(user) {
  const list = $('channel-list');
  const el = document.createElement('div');
  el.className = 'voice-user';
  el.id = `vu-${user.id}`;
  el.innerHTML = `<div class="voice-user-avatar">${user.username[0].toUpperCase()}</div>${escapeHtml(user.username)}`;
  list.appendChild(el);
}
function removeVoiceUser(uid) {
  const el = document.getElementById(`vu-${uid}`);
  if (el) el.remove();
}

// Voice controls
$('btn-voice-mute').addEventListener('click', () => {
  micMuted = !micMuted;
  if (localStream) localStream.getAudioTracks().forEach(t => t.enabled = !micMuted);
  $('btn-voice-mute').textContent = micMuted ? '🔇' : '🎤';
  $('btn-voice-mute').classList.toggle('muted', micMuted);
});

$('btn-voice-leave').addEventListener('click', async () => {
  await leaveVoice();
  if (currentChannel) {
    const first = currentServer?.channels?.find(c => c.type === 'text');
    if (first) selectChannel(first);
  }
});

// Panel controls
$('btn-mute').addEventListener('click', () => {
  micMuted = !micMuted;
  if (localStream) localStream.getAudioTracks().forEach(t => t.enabled = !micMuted);
  $('btn-mute').textContent = micMuted ? '🔇' : '🎤';
});

$('btn-deafen').addEventListener('click', () => {
  deafened = !deafened;
  document.querySelectorAll('#audio-container audio').forEach(a => a.muted = deafened);
  $('btn-deafen').textContent = deafened ? '🔕' : '🔊';
});

$('btn-logout').addEventListener('click', async () => {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
  await leaveVoice();
  if (socket) { socket.disconnect(); socket = null; }
  token = null; currentUser = null; currentServer = null; currentChannel = null;
  localStorage.removeItem('srw_token');
  hide($('app-screen'));
  show($('auth-screen'));
});

// ── Server management ─────────────────────────────
$('btn-create-server').addEventListener('click', () => openModal('modal-create-server'));
$('btn-join-server').addEventListener('click', () => openModal('modal-join-server'));

$('confirm-create-server').addEventListener('click', async () => {
  const name = $('new-server-name').value.trim();
  if (!name) return;
  try {
    const s = await api('/api/servers', { method: 'POST', body: JSON.stringify({ name }) });
    servers.push(s);
    renderServerList();
    selectServer(s);
    closeModal();
    toast(`Serwer "${s.name}" utworzony!`);
  } catch (e) { toast(e.message, 'error'); }
});

$('confirm-join-server').addEventListener('click', async () => {
  const code = $('invite-code-input').value.trim();
  if (!code) return;
  try {
    const { server_id } = await api(`/api/invite/${code}`, { method: 'POST' });
    await loadServers();
    const s = servers.find(sv => sv.id === server_id);
    if (s) selectServer(s);
    closeModal();
    toast('Dołączono do serwera!');
  } catch (e) { toast(e.message, 'error'); }
});

$('btn-invite').addEventListener('click', () => {
  if (!currentServer) return;
  const link = `${window.location.origin}/?invite=${currentServer.invite}`;
  $('invite-link-value').value = link;
  openModal('modal-invite');
});

$('btn-copy-invite').addEventListener('click', () => {
  navigator.clipboard.writeText($('invite-link-value').value);
  toast('Link skopiowany!');
});

// ── Modals ────────────────────────────────────────
function openModal(id) {
  hide($('modal-overlay').querySelector('.modal:not(.hidden)') || { classList: { add: () => {} } });
  document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
  $('modal-overlay').querySelector(`#${id}`)?.classList.remove('hidden');
  show($('modal-overlay'));
}
function closeModal() {
  hide($('modal-overlay'));
}

$('modal-overlay').addEventListener('click', e => {
  if (e.target === $('modal-overlay')) closeModal();
});
document.querySelectorAll('[data-close]').forEach(btn => {
  btn.addEventListener('click', closeModal);
});

// Auto-join invite from URL
(function checkInviteUrl() {
  const params = new URLSearchParams(window.location.search);
  const invite = params.get('invite');
  if (invite) {
    $('invite-code-input').value = invite;
  }
})();

// ── Bootstrap ─────────────────────────────────────
(async function init() {
  await initRecaptcha();
  if (token) {
    try {
      currentUser = await api('/api/me');
      enterApp();
    } catch {
      localStorage.removeItem('srw_token');
      token = null;
    }
  }
})();
