# 🎮 Serwerek Chat — Instrukcja instalacji

Aplikacja webowa inspirowana Discordem: czat tekstowy, voice chat (WebRTC),
reCAPTCHA v2, trwała baza danych SQLite.

---

## 📁 Struktura projektu

```
serwerek/
├── app.py                  # Backend Flask + SocketIO
├── requirements.txt        # Zależności Python
├── ecosystem.config.js     # Konfiguracja PM2
├── nginx-serwerek.conf     # Konfiguracja Nginx + SSL
├── chat.db                 # Baza danych SQLite (tworzy się automatycznie)
├── templates/
│   └── index.html          # Frontend HTML
└── static/
    ├── css/app.css
    └── js/app.js
```

---

## 🚀 Instalacja krok po kroku

### 1. Wymagania systemowe
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv nginx -y
```

### 2. Klonowanie / kopiowanie projektu
```bash
mkdir -p /home/user/serwerek
# Skopiuj wszystkie pliki projektu do /home/user/serwerek
cd /home/user/serwerek
```

### 3. Środowisko Python
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Test aplikacji
```bash
python3 app.py
# Otwórz http://localhost:3000
# Domyślne konto: Admin / admin1234
```

---

## 🔐 Konfiguracja SSL (certwerek.com.pl)

### Krok 1: Przygotowanie certyfikatów
```bash
sudo mkdir -p /etc/ssl/serwerek
sudo chmod 700 /etc/ssl/serwerek

# Skopiuj pliki z dysku do serwera (np. przez SCP):
scp serwerek.com.pl.certificate.pem  user@serwer:/etc/ssl/serwerek/cert.pem
scp serwerek.com.pl.intermediate.pem user@serwer:/etc/ssl/serwerek/intermediate.pem
scp serwerek.com.pl.key.txt          user@serwer:/etc/ssl/serwerek/key.pem

# LUB jeśli już jesteś na serwerze:
sudo cp /ścieżka/do/serwerek.com.pl.certificate.pem  /etc/ssl/serwerek/cert.pem
sudo cp /ścieżka/do/serwerek.com.pl.intermediate.pem /etc/ssl/serwerek/intermediate.pem
sudo cp /ścieżka/do/serwerek.com.pl.key.txt          /etc/ssl/serwerek/key.pem
```

### Krok 2: Połącz cert z intermediate (fullchain)
```bash
sudo cat /etc/ssl/serwerek/cert.pem \
         /etc/ssl/serwerek/intermediate.pem \
         > /etc/ssl/serwerek/fullchain.pem

sudo chmod 600 /etc/ssl/serwerek/key.pem
sudo chmod 644 /etc/ssl/serwerek/fullchain.pem
```

### Krok 3: Konfiguracja Nginx
```bash
sudo cp nginx-serwerek.conf /etc/nginx/sites-available/serwerek.conf
sudo ln -s /etc/nginx/sites-available/serwerek.conf /etc/nginx/sites-enabled/

# Sprawdź konfigurację:
sudo nginx -t

# Reload:
sudo systemctl reload nginx
sudo systemctl enable nginx
```

---

## ⚡ PM2 (zarządzanie procesem)

### 1. Instalacja PM2
```bash
sudo npm install -g pm2
```

### 2. Edytuj ecosystem.config.js
Zmień ścieżkę `cwd` oraz `SECRET_KEY`:
```js
cwd: "/home/user/serwerek",
env: {
  SECRET_KEY: "twój-losowy-klucz-32-znaki",
  PORT: 3000
}
```

### 3. Uruchom z PM2
```bash
cd /home/user/serwerek
mkdir -p logs

# Uruchom z venv Python:
pm2 start ecosystem.config.js
pm2 save
pm2 startup    # Pokaże komendę do wklejenia dla autostartu po restarcie
```

### 4. Komendy PM2
```bash
pm2 list                    # Lista procesów
pm2 logs serwerek-chat      # Logi
pm2 restart serwerek-chat   # Restart
pm2 stop serwerek-chat      # Stop
pm2 delete serwerek-chat    # Usuń
pm2 monit                   # Monitor CPU/RAM
```

---

## 🔒 Zmiana ścieżki do Python w PM2

Jeśli używasz virtualenv, w `ecosystem.config.js` zmień:
```js
interpreter: "/home/user/serwerek/venv/bin/python3",
```

---

## 🌐 DNS

W panelu DNS swojej domeny ustaw:
```
A    serwerek.com.pl     →  IP_SERWERA
A    www.serwerek.com.pl →  IP_SERWERA
```

---

## 🔑 Klucze reCAPTCHA (już skonfigurowane w app.py)

- **Site key** (frontend): `6LeI664sAAAAFRsIKRmGfA_RNFUGGy74SB3BI84`
- **Secret key** (backend): `6LeI664sAAAAAECwhUPJVa6UfVs-Iz3SI2ovPPEj`

Klucze są już wpisane w `app.py`. Upewnij się, że w Google reCAPTCHA Console
masz dodaną domenę `serwerek.com.pl` do listy dozwolonych domen.

---

## 🗄️ Baza danych

Dane są przechowywane w pliku `chat.db` (SQLite).
Plik powstaje automatycznie przy pierwszym uruchomieniu.
Konta użytkowników, wiadomości i serwery **przetrwają restart aplikacji**.

Backup:
```bash
cp chat.db chat.db.backup
```

---

## 🎤 Voice chat

Voice chat używa WebRTC (peer-to-peer).
- Kliknij na kanał głosowy (ikona 🔊) — przeglądarka poprosi o dostęp do mikrofonu
- Użyj przycisku 🎤 aby wyciszyć mikrofon
- Użyj 📵 aby rozłączyć się z kanału głosowego
- STUN servers: Google (stun.l.google.com) — działa bez dodatkowej konfiguracji
- Dla produkcji z NAT zalecany jest TURN server (np. Coturn)

---

## 📋 Domyślne konto

```
Użytkownik: Admin
Hasło:      admin1234
```

**Zmień hasło po pierwszym logowaniu!**
(Usuń użytkownika z bazy i zarejestruj nowego, lub zmodyfikuj app.py)

---

## 🔧 Troubleshooting

**App nie startuje:**
```bash
cd /home/user/serwerek && python3 app.py
# Sprawdź błędy w konsoli
```

**Nginx 502:**
```bash
# Upewnij się że app działa na porcie 3000
pm2 logs serwerek-chat
```

**reCAPTCHA nie przechodzi:**
- Dodaj `serwerek.com.pl` w Google reCAPTCHA Console → Ustawienia witryny
- Dla testów lokalnych (localhost) dodaj też `localhost`

**Voice nie działa:**
- HTTPS jest wymagany dla getUserMedia (mikrofon)
- Sprawdź czy przeglądarka ma uprawnienia do mikrofonu
