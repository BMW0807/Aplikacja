#!/usr/bin/env python3
"""
Discord-like Chat App
Backend: Flask + Flask-SocketIO + SQLite
"""

import os
import json
import uuid
import hashlib
import secrets
import requests
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, request, jsonify, send_from_directory, session
from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect
from flask_cors import CORS
import sqlite3

# ── Config ──────────────────────────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY", secrets.token_hex(32))
RECAPTCHA_SECRET = "6LeI664sAAAAAECwhUPJVa6UfVs-Iz3SI2ovPPEj"
RECAPTCHA_SITE   = "6LeI664sAAAAFRsIKRmGfA_RNFUGGy74SB3BI84"
DB_PATH = os.path.join(os.path.dirname(__file__), "chat.db")

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = SECRET_KEY
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = True
CORS(app, supports_credentials=True)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ── Database ─────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id       TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            avatar   TEXT DEFAULT NULL,
            status   TEXT DEFAULT 'offline',
            created  TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS servers (
            id      TEXT PRIMARY KEY,
            name    TEXT NOT NULL,
            owner   TEXT NOT NULL,
            icon    TEXT DEFAULT NULL,
            created TEXT NOT NULL,
            FOREIGN KEY(owner) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS channels (
            id        TEXT PRIMARY KEY,
            server_id TEXT NOT NULL,
            name      TEXT NOT NULL,
            type      TEXT DEFAULT 'text',
            position  INTEGER DEFAULT 0,
            created   TEXT NOT NULL,
            FOREIGN KEY(server_id) REFERENCES servers(id)
        );

        CREATE TABLE IF NOT EXISTS members (
            server_id TEXT NOT NULL,
            user_id   TEXT NOT NULL,
            role      TEXT DEFAULT 'member',
            joined    TEXT NOT NULL,
            PRIMARY KEY(server_id, user_id)
        );

        CREATE TABLE IF NOT EXISTS messages (
            id         TEXT PRIMARY KEY,
            channel_id TEXT NOT NULL,
            user_id    TEXT NOT NULL,
            content    TEXT NOT NULL,
            type       TEXT DEFAULT 'text',
            edited     INTEGER DEFAULT 0,
            created    TEXT NOT NULL,
            FOREIGN KEY(channel_id) REFERENCES channels(id),
            FOREIGN KEY(user_id)    REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS sessions (
            token    TEXT PRIMARY KEY,
            user_id  TEXT NOT NULL,
            expires  TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS invites (
            code      TEXT PRIMARY KEY,
            server_id TEXT NOT NULL,
            creator   TEXT NOT NULL,
            expires   TEXT,
            uses      INTEGER DEFAULT 0
        );
        """)
        db.commit()

        # Seed default server
        existing = db.execute("SELECT id FROM servers LIMIT 1").fetchone()
        if not existing:
            sid = str(uuid.uuid4())
            now = datetime.utcnow().isoformat()
            # Create bot user
            uid = str(uuid.uuid4())
            pw  = hashlib.sha256(b"admin1234").hexdigest()
            db.execute("INSERT OR IGNORE INTO users VALUES (?,?,?,NULL,'offline',?)",
                       (uid, "Admin", pw, now))
            db.execute("INSERT INTO servers VALUES (?,?,?,NULL,?)",
                       (sid, "Serwerek", uid, now))
            db.execute("INSERT INTO members VALUES (?,?,?,?)",
                       (sid, uid, "owner", now))
            # Default channels
            for i, (cname, ctype) in enumerate([
                ("ogólny", "text"),
                ("losowy", "text"),
                ("głosowy", "voice"),
            ]):
                cid = str(uuid.uuid4())
                db.execute("INSERT INTO channels VALUES (?,?,?,?,?,?)",
                           (cid, sid, cname, ctype, i, now))
            db.execute("INSERT INTO invites VALUES (?,?,?,NULL,0)",
                       ("serwerek", sid, uid))
            db.commit()
            print("[DB] Seed complete — Admin / admin1234")

init_db()

# ── Auth helpers ─────────────────────────────────────────────────────────────
def hash_pw(pw): return hashlib.sha256(pw.encode()).hexdigest()

def get_token():
    return request.headers.get("Authorization", "").replace("Bearer ", "").strip()

def current_user():
    token = get_token()
    if not token: return None
    with get_db() as db:
        row = db.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
            "WHERE s.token=? AND s.expires > ?",
            (token, datetime.utcnow().isoformat())).fetchone()
    return dict(row) if row else None

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user:
            return jsonify({"error": "Unauthorized"}), 401
        return f(user, *args, **kwargs)
    return wrapper

# ── reCAPTCHA ────────────────────────────────────────────────────────────────
def verify_recaptcha(token):
    try:
        r = requests.post("https://www.google.com/recaptcha/api/siteverify",
                          data={"secret": RECAPTCHA_SECRET, "response": token},
                          timeout=5)
        return r.json().get("success", False)
    except Exception:
        return False

# ── REST API ──────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory("templates", "index.html")

@app.route("/api/recaptcha-site-key")
def recaptcha_key():
    return jsonify({"key": RECAPTCHA_SITE})

@app.route("/api/auth/register", methods=["POST"])
def register():
    d = request.json or {}
    username  = (d.get("username") or "").strip()
    password  = d.get("password", "")
    captcha   = d.get("captcha", "")

    if not username or not password:
        return jsonify({"error": "Wypełnij wszystkie pola"}), 400
    if len(username) < 2 or len(username) > 32:
        return jsonify({"error": "Nazwa 2-32 znaki"}), 400
    if len(password) < 6:
        return jsonify({"error": "Hasło min. 6 znaków"}), 400
    if not verify_recaptcha(captcha):
        return jsonify({"error": "Weryfikacja reCAPTCHA nieudana"}), 400

    uid  = str(uuid.uuid4())
    now  = datetime.utcnow().isoformat()
    try:
        with get_db() as db:
            db.execute("INSERT INTO users VALUES (?,?,?,NULL,'offline',?)",
                       (uid, username, hash_pw(password), now))
            db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "Nazwa użytkownika zajęta"}), 409

    return jsonify({"ok": True}), 201

@app.route("/api/auth/login", methods=["POST"])
def login():
    d = request.json or {}
    username = (d.get("username") or "").strip()
    password = d.get("password", "")
    captcha  = d.get("captcha", "")

    if not verify_recaptcha(captcha):
        return jsonify({"error": "Weryfikacja reCAPTCHA nieudana"}), 400

    with get_db() as db:
        user = db.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (username, hash_pw(password))).fetchone()
        if not user:
            return jsonify({"error": "Nieprawidłowe dane"}), 401

        token   = secrets.token_hex(32)
        expires = (datetime.utcnow() + timedelta(days=30)).isoformat()
        db.execute("INSERT INTO sessions VALUES (?,?,?)", (token, user["id"], expires))
        db.execute("UPDATE users SET status='online' WHERE id=?", (user["id"],))
        db.commit()

    return jsonify({"token": token, "user": {
        "id": user["id"], "username": user["username"], "avatar": user["avatar"]
    }})

@app.route("/api/auth/logout", methods=["POST"])
@login_required
def logout(user):
    token = get_token()
    with get_db() as db:
        db.execute("DELETE FROM sessions WHERE token=?", (token,))
        db.execute("UPDATE users SET status='offline' WHERE id=?", (user["id"],))
        db.commit()
    return jsonify({"ok": True})

@app.route("/api/me")
@login_required
def me(user):
    return jsonify(user)

# ── Servers ───────────────────────────────────────────────────────────────────
@app.route("/api/servers")
@login_required
def list_servers(user):
    with get_db() as db:
        rows = db.execute(
            "SELECT s.* FROM servers s JOIN members m ON m.server_id=s.id "
            "WHERE m.user_id=? ORDER BY s.created", (user["id"],)).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/servers", methods=["POST"])
@login_required
def create_server(user):
    d    = request.json or {}
    name = (d.get("name") or "").strip()
    if not name: return jsonify({"error": "Podaj nazwę serwera"}), 400

    sid = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    with get_db() as db:
        db.execute("INSERT INTO servers VALUES (?,?,?,NULL,?)", (sid, name, user["id"], now))
        db.execute("INSERT INTO members VALUES (?,?,?,?)", (sid, user["id"], "owner", now))
        for i, (cname, ctype) in enumerate([("ogólny","text"),("głosowy","voice")]):
            cid = str(uuid.uuid4())
            db.execute("INSERT INTO channels VALUES (?,?,?,?,?,?)",
                       (cid, sid, cname, ctype, i, now))
        code = secrets.token_urlsafe(8)
        db.execute("INSERT INTO invites VALUES (?,?,?,NULL,0)", (code, sid, user["id"]))
        db.commit()
        server = db.execute("SELECT * FROM servers WHERE id=?", (sid,)).fetchone()
    return jsonify(dict(server)), 201

@app.route("/api/servers/<sid>")
@login_required
def get_server(user, sid):
    with get_db() as db:
        member = db.execute("SELECT * FROM members WHERE server_id=? AND user_id=?",
                            (sid, user["id"])).fetchone()
        if not member: return jsonify({"error": "Brak dostępu"}), 403
        server   = dict(db.execute("SELECT * FROM servers WHERE id=?", (sid,)).fetchone())
        channels = [dict(r) for r in db.execute(
            "SELECT * FROM channels WHERE server_id=? ORDER BY position", (sid,)).fetchall()]
        members  = [dict(r) for r in db.execute(
            "SELECT u.id,u.username,u.avatar,u.status,m.role FROM members m "
            "JOIN users u ON u.id=m.user_id WHERE m.server_id=?", (sid,)).fetchall()]
        invite   = db.execute("SELECT code FROM invites WHERE server_id=? LIMIT 1",
                              (sid,)).fetchone()
    server["channels"] = channels
    server["members"]  = members
    server["invite"]   = invite["code"] if invite else None
    return jsonify(server)

@app.route("/api/invite/<code>", methods=["POST"])
@login_required
def join_server(user, code):
    now = datetime.utcnow().isoformat()
    with get_db() as db:
        inv = db.execute("SELECT * FROM invites WHERE code=?", (code,)).fetchone()
        if not inv: return jsonify({"error": "Nieprawidłowy kod"}), 404
        existing = db.execute("SELECT 1 FROM members WHERE server_id=? AND user_id=?",
                              (inv["server_id"], user["id"])).fetchone()
        if not existing:
            db.execute("INSERT INTO members VALUES (?,?,?,?)",
                       (inv["server_id"], user["id"], "member", now))
            db.execute("UPDATE invites SET uses=uses+1 WHERE code=?", (code,))
            db.commit()
    return jsonify({"server_id": inv["server_id"]})

# ── Channels / Messages ───────────────────────────────────────────────────────
@app.route("/api/channels/<cid>/messages")
@login_required
def get_messages(user, cid):
    limit  = min(int(request.args.get("limit", 50)), 100)
    before = request.args.get("before", "")
    with get_db() as db:
        if before:
            rows = db.execute(
                "SELECT m.*,u.username,u.avatar FROM messages m "
                "JOIN users u ON u.id=m.user_id "
                "WHERE m.channel_id=? AND m.created < ? "
                "ORDER BY m.created DESC LIMIT ?", (cid, before, limit)).fetchall()
        else:
            rows = db.execute(
                "SELECT m.*,u.username,u.avatar FROM messages m "
                "JOIN users u ON u.id=m.user_id "
                "WHERE m.channel_id=? ORDER BY m.created DESC LIMIT ?",
                (cid, limit)).fetchall()
    return jsonify([dict(r) for r in reversed(rows)])

@app.route("/api/channels/<cid>/messages", methods=["POST"])
@login_required
def send_message(user, cid):
    d       = request.json or {}
    content = (d.get("content") or "").strip()
    if not content: return jsonify({"error": "Pusta wiadomość"}), 400

    mid = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    with get_db() as db:
        db.execute("INSERT INTO messages VALUES (?,?,?,?,?,?,?)",
                   (mid, cid, user["id"], content, "text", 0, now))
        db.commit()
        msg = dict(db.execute(
            "SELECT m.*,u.username,u.avatar FROM messages m "
            "JOIN users u ON u.id=m.user_id WHERE m.id=?", (mid,)).fetchone())

    socketio.emit("new_message", msg, room=f"channel_{cid}")
    return jsonify(msg), 201

# ── WebSocket ─────────────────────────────────────────────────────────────────
connected_users = {}  # socket_id -> user_id
voice_rooms     = {}  # channel_id -> set(user_id)

@socketio.on("connect")
def on_connect():
    token = request.args.get("token", "")
    with get_db() as db:
        row = db.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id "
            "WHERE s.token=? AND s.expires > ?",
            (token, datetime.utcnow().isoformat())).fetchone()
    if not row:
        disconnect()
        return
    user = dict(row)
    connected_users[request.sid] = user["id"]
    with get_db() as db:
        db.execute("UPDATE users SET status='online' WHERE id=?", (user["id"],))
        db.commit()
    emit("authenticated", {"user": user})

@socketio.on("disconnect")
def on_disconnect():
    uid = connected_users.pop(request.sid, None)
    if uid:
        with get_db() as db:
            db.execute("UPDATE users SET status='offline' WHERE id=?", (uid,))
            db.commit()
        # Leave voice rooms
        for cid, members in list(voice_rooms.items()):
            if uid in members:
                members.discard(uid)
                emit("voice_left", {"user_id": uid, "channel_id": cid},
                     room=f"voice_{cid}", broadcast=True)

@socketio.on("join_channel")
def on_join_channel(data):
    cid = data.get("channel_id")
    join_room(f"channel_{cid}")

@socketio.on("leave_channel")
def on_leave_channel(data):
    cid = data.get("channel_id")
    leave_room(f"channel_{cid}")

@socketio.on("typing")
def on_typing(data):
    uid = connected_users.get(request.sid)
    cid = data.get("channel_id")
    if uid and cid:
        with get_db() as db:
            u = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
        emit("user_typing", {"user_id": uid, "username": u["username"], "channel_id": cid},
             room=f"channel_{cid}", include_self=False)

# ── Voice signaling (WebRTC) ──────────────────────────────────────────────────
@socketio.on("voice_join")
def voice_join(data):
    uid = connected_users.get(request.sid)
    cid = data.get("channel_id")
    if not uid or not cid: return
    join_room(f"voice_{cid}")
    voice_rooms.setdefault(cid, set()).add(uid)
    with get_db() as db:
        u = db.execute("SELECT id,username,avatar FROM users WHERE id=?", (uid,)).fetchone()
    emit("voice_joined", {"user": dict(u), "channel_id": cid},
         room=f"voice_{cid}", include_self=False)
    # Send existing participants to joiner
    participants = []
    for member_id in voice_rooms.get(cid, set()):
        if member_id != uid:
            with get_db() as db:
                mu = db.execute("SELECT id,username,avatar FROM users WHERE id=?",
                                (member_id,)).fetchone()
            if mu: participants.append(dict(mu))
    emit("voice_participants", {"participants": participants, "channel_id": cid})

@socketio.on("voice_leave")
def voice_leave(data):
    uid = connected_users.get(request.sid)
    cid = data.get("channel_id")
    if uid and cid:
        voice_rooms.get(cid, set()).discard(uid)
        leave_room(f"voice_{cid}")
        emit("voice_left", {"user_id": uid, "channel_id": cid},
             room=f"voice_{cid}", broadcast=True)

@socketio.on("webrtc_offer")
def webrtc_offer(data):
    emit("webrtc_offer", data, room=f"voice_{data['channel_id']}", include_self=False)

@socketio.on("webrtc_answer")
def webrtc_answer(data):
    emit("webrtc_answer", data, room=f"voice_{data['channel_id']}", include_self=False)

@socketio.on("webrtc_ice")
def webrtc_ice(data):
    emit("webrtc_ice", data, room=f"voice_{data['channel_id']}", include_self=False)

# ── Static files ──────────────────────────────────────────────────────────────
@app.route("/static/<path:path>")
def static_files(path):
    return send_from_directory("static", path)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 3000))
    socketio.run(app, host="0.0.0.0", port=port, debug=False)
