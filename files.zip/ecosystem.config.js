module.exports = {
  apps: [
    {
      name: "serwerek-chat",
      script: "app.py",
      interpreter: "python3",
      cwd: "/home/user/serwerek",   // ← zmień na ścieżkę do projektu
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "500M",
      env: {
        PORT: 3000,
        SECRET_KEY: "ZMIEN_NA_LOSOWY_CIAG_ZNAKOW_32_BAJTOW",
        NODE_ENV: "production"
      },
      error_file:  "./logs/err.log",
      out_file:    "./logs/out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss"
    }
  ]
};
